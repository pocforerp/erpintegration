using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Transactions;
using System.Text.RegularExpressions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Security;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System.Xml;
using System.Xml.Linq;

namespace Cmf.Foundation.Common.DynamicExpressionEvaluator.Runtime
{
    public class RuleEvaluator_RXh0ZXJuYWxTeXN0ZW1Qcm9jZXNzQWN0aW9u : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, Object> EvaluateRule(Dictionary<string, Object> Input) 
        {
            /** START OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
            // references
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "");
            UseReference("%MicrosoftNetPath%System.Xml.dll", "");
            UseReference("%MicrosoftNetPath%System.Xml.Linq.dll", "");

            // namespaces
            UseReference("", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("", "Cmf.Navigo.BusinessObjects");
            UseReference("", "System.Xml");
            UseReference("", "System.Xml.Linq");

            IntegrationEntry integrationEntry = Input["IntegrationEntry"] as IntegrationEntry;
            IntegrationMessage integration = Input["IntegrationMessage"] as IntegrationMessage;
            string messageBody = Input["IntegrationMessageMessage"] as string;
            
            //Create ProductionOrderCollection Instance for multiple orders
            ProductionOrderCollection POsToCreate = new ProductionOrderCollection();

            //Parse the xml....
            XDocument xDocument = XDocument.Parse(messageBody);
            IEnumerable<XElement> productionOrders = xDocument.Root.Descendants("ProductionOrder");
            string strorderNumber = "OrderNumber";
            string strtypeOfOrder = "Type";
            string strproduct = "Product";
            string strQuantity = "Quantity";
            string strUnits = "Units";
            string strDueDate = "DueDate";

            if (productionOrders == null || !productionOrders.Any())
            {
                throw new Exception("Theere is no Production Order to process in IntegrationMessage.");
            }
            XElement xmlProd;
            foreach (XElement productionOrder in productionOrders)
            {
                ProductionOrder pOrder = new ProductionOrder();
                xmlProd = productionOrder.Elements(strorderNumber).FirstOrDefault();
                if (xmlProd != null)
                {
                    pOrder.OrderNumber = xmlProd.Value;
                    pOrder.Name = xmlProd.Value;
                }
                xmlProd = productionOrder.Elements(strtypeOfOrder).FirstOrDefault();
                if (xmlProd != null)
                {
                    pOrder.Type = xmlProd.Value;
                }
                xmlProd = productionOrder.Elements(strproduct).FirstOrDefault();
                if (xmlProd != null && xmlProd.Value != null)
                {
                    Product product = new Product { Name = xmlProd.Value };
                    product.Load();
                    if (product.UniversalState != UniversalState.Effective)
                    {
                        throw new InvalidObjectStateCmfException(product.Name, UniversalState.Effective.ToString());
                    }
                    pOrder.Product = product;

                    xmlProd = productionOrder.Elements(strQuantity).FirstOrDefault();
                    if (xmlProd != null && xmlProd.Value != null)
                    {
                        decimal Quantity = 0.0M;
                        decimal.TryParse(xmlProd.Value.ToString(), out Quantity);
                        pOrder.Quantity = Quantity;
                    }
                    xmlProd = productionOrder.Elements(strUnits).FirstOrDefault();
                    if (xmlProd != null && xmlProd.Value != null)
                    {
                        pOrder.Units = xmlProd.Value.ToString();
                    }
                    xmlProd = productionOrder.Elements(strDueDate).FirstOrDefault();
                    if (xmlProd != null && xmlProd.Value != null)
                    {
                        pOrder.DueDate = Convert.ToDateTime(xmlProd.Value);
                    }
                }
                POsToCreate.Add(pOrder);
            }

            if (POsToCreate.Count > 0)
            {
                POsToCreate.Create();

                string notificationDetails = string.Format("Below PO's where added by the '{0}' external system", integrationEntry.SourceSystem);
                notificationDetails += "<br>";
                foreach (ProductionOrder po in POsToCreate)
                {
                    notificationDetails += string.Format("<br> {0}", po.OrderNumber);
                }

                Notification notification = new Notification();
                notification.Title = "Newly Added POs";
                notification.Details = notificationDetails;
                notification.Type = "General";
                notification.Severity = "Information";
                notification.SystemState = NotificationSystemState.Open;
                notification.SourceType = SourceType.System;
                notification.AssignmentType = AssignmentType.Everyone;
                notification.SendEmailToAssignedParty = false;
                notification.VisibilityFilter = VisibilityFilter.None;
                notification.ValidTo = DateTime.Now.AddHours(3);
                notification.Create();
            }

            /** END OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
            return Input;
        }

        public override Boolean ValidateAction(Dictionary<string, Object> Input) 
        {
            /** START OF USER-DEFINED VALIDATION CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/

            bool hasError = false;
            string errorMessage = string.Empty;

            if (Input == null)
            {                
                return false;
            }

            if (!Input.ContainsKey("IntegrationEntry"))
            {
                return false;
            }

            if (!(Input["IntegrationEntry"] is IntegrationEntry))
            {
                return false;
            }

            IntegrationEntry integrationEntry = Input["IntegrationEntry"] as IntegrationEntry;

            // this Action should only handle entries from the 'ExternalErp' system
            if (string.IsNullOrWhiteSpace(integrationEntry.SourceSystem)
                    || !integrationEntry.SourceSystem.Equals("ExternalSystem"))
            {
                return false;
            }

            // this Action should only handle entries to the 'MES' system.
            if (string.IsNullOrWhiteSpace(integrationEntry.TargetSystem)
                    || !integrationEntry.TargetSystem.Equals("MES"))
            {
                return false;
            }

            if (!hasError && !Input.ContainsKey("IntegrationMessage"))
            {
                hasError = true;
                errorMessage = "The Action could not establish the message object from the input";
            }

            if (!hasError && !(Input["IntegrationMessage"] is IntegrationMessage))
            {
                hasError = true;
                errorMessage = "The Action could not establish the message object from the input";
            }

            if (!hasError && !Input.ContainsKey("IntegrationMessageMessage"))
            {
                hasError = true;
                errorMessage = "The Action could not establish the message body from the input";
            }

            if (!hasError && !(Input["IntegrationMessageMessage"] is string))
            {
                hasError = true;
                errorMessage = "The Action could not establish the message body from the input";
            }

            if (hasError)
            {
                integrationEntry.Fail(errorMessage);
                return false;
            }

            return true;
            
            /** END OF USER-DEFINED VALIDATION CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
        }
    }
}