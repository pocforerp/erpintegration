using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Transactions;
using System.Text.RegularExpressions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Security;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Exceptions;
using Cmf.Foundation.Common;

namespace Cmf.Foundation.Common.DynamicExpressionEvaluator.Runtime
{
    public class RuleEvaluator_RXh0ZXJuYWxTeXN0ZW1NZXNzc2FnZUdlbmVyYXRvcg : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, Object> EvaluateRule(Dictionary<string, Object> Input) 
        {
            /** START OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
// references
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            // namespaces
            UseReference("", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // information from the  SmartTable 'IntegrationHandlerResolution' (routing table)
            string IntegrationHandlerResolution_FromSystem = "ExternalSystem";
            string IntegrationHandlerResolution_ToSystem = "MES";
            string IntegrationHandlerResolution_MessageType = "ExternalSystemMessageType";

            //string messageBody = "<?xml version=\"1.0\"?> <Message> <Material> <Name>IntegrationMaterial01</Name> <Type>Production</Type> <Form>Lot</Form> <PrimaryQuantity>100</PrimaryQuantity> <PrimaryUnits>Kg</PrimaryUnits> <Facility>Cookie Factory</Facility> <Product>Belgas</Product> <Flow>CookiesFlow</Flow> <Step>Mixing</Step> </Material> <Material> <Name>IntegrationMaterial02</Name> <Type>Production</Type> <Form>Lot</Form> <PrimaryQuantity>100</PrimaryQuantity> <PrimaryUnits>Kg</PrimaryUnits> <Facility>Cookie Factory</Facility> <Product>Belgas</Product> <Flow>CookiesFlow</Flow> <Step>Mixing</Step> </Material> </Message>";

            string messageBody = "<?xml version=\"1.0\"?> <Message> <ProductionOrder> " +
            "<OrderNumber>689815529</OrderNumber> <Type>General</Type> <Product>Belgas</Product> " +
            "<Quantity>20000</Quantity> <Units>Kg</Units> <DueDate>2020-12-25 00:00</DueDate> " +
            "</ProductionOrder> <ProductionOrder> <OrderNumber>928302858</OrderNumber> " +
            "<Type>General</Type> <Product>Milka</Product> <Quantity>50000</Quantity> " +
            "<Units>Kg</Units> <DueDate>2021-01-01 00:00</DueDate> </ProductionOrder> </Message>";
            
            // setup IntegrationEntry message
            IntegrationMessage integrationMessage = new IntegrationMessage();

            // build 
            using (var stream = Utilities.ZipToStream(string.Empty, messageBody, string.Empty))
            {
                integrationMessage.Message = stream.ToArray();
            }

            // setup IntegrationEntry
            IntegrationEntry integrationEntry = new IntegrationEntry();
            integrationEntry.Name = Guid.NewGuid().ToString();
            integrationEntry.EventName = "Received";
            integrationEntry.SourceSystem = IntegrationHandlerResolution_FromSystem;
            integrationEntry.TargetSystem = IntegrationHandlerResolution_ToSystem;
            integrationEntry.SystemState = Integration.IntegrationEntrySystemState.Received;
            integrationEntry.IsRetriable = false;
            integrationEntry.MessageDate = DateTime.UtcNow;
            integrationEntry.MessageName = null;
            integrationEntry.MessageType = IntegrationHandlerResolution_MessageType;
            integrationEntry.IntegrationMessage = integrationMessage;

            // create IntegrationEntry & IntegrationMessage
            integrationEntry.Create();
            /** END OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
            return Input;
        }

        public override Boolean ValidateAction(Dictionary<string, Object> Input) 
        {
            /** START OF USER-DEFINED VALIDATION CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
return true;
            /** END OF USER-DEFINED VALIDATION CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/
        }
    }
}
